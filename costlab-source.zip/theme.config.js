/** @type {const} */
const themeColors = {
  primary: { light: '#1b365d', dark: '#7fb3e4' },
  background: { light: '#f5f7fb', dark: '#101827' },
  surface: { light: '#ffffff', dark: '#172235' },
  foreground: { light: '#0f172a', dark: '#f8fafc' },
  muted: { light: '#64748b', dark: '#a8b5c7' },
  border: { light: '#e2e8f0', dark: '#334155' },
  success: { light: '#059669', dark: '#34d399' },
  warning: { light: '#d97706', dark: '#fbbf24' },
  error: { light: '#dc2626', dark: '#f87171' },
};

module.exports = { themeColors };
