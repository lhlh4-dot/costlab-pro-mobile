import { useMemo } from "react";
import { View, type ViewProps } from "react-native";
import { useSafeAreaInsets, type Edge } from "react-native-safe-area-context";

import { cn } from "@/lib/utils";

export interface ScreenContainerProps extends ViewProps {
  edges?: Edge[];
  className?: string;
  containerClassName?: string;
  safeAreaClassName?: string;
}

export function ScreenContainer({
  children,
  edges = ["top", "left", "right"],
  className,
  containerClassName,
  safeAreaClassName,
  style,
  ...props
}: ScreenContainerProps) {
  const insets = useSafeAreaInsets();
  const safeAreaStyle = useMemo(
    () => ({
      paddingTop: edges.includes("top") ? insets.top : 0,
      paddingBottom: edges.includes("bottom") ? insets.bottom : 0,
      paddingLeft: edges.includes("left") ? insets.left : 0,
      paddingRight: edges.includes("right") ? insets.right : 0,
    }),
    [edges, insets],
  );

  return (
    <View className={cn("flex-1", "bg-background", containerClassName)} {...props}>
      <View className={cn("flex-1", safeAreaClassName)} style={[safeAreaStyle, style]}>
        <View className={cn("flex-1", className)}>{children}</View>
      </View>
    </View>
  );
}
